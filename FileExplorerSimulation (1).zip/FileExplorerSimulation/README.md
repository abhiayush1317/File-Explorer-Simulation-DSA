# File Explorer Simulation (DSA Mini Project)

A virtual file explorer written in Python + Tkinter. It manages its own
files and folders in memory (nothing on your real disk is touched) and
saves them to `data/explorer.json`.

## Run in VS Code
1. Install Python 3.9+ (Tkinter is included with the python.org installer;
   on Ubuntu/Debian: `sudo apt install python3-tk`).
2. Open the `FileExplorerSimulation` folder in VS Code.
3. Open a terminal and run: `python main.py`
4. Tests: `python -m unittest discover -s tests -v`

No external libraries are needed (see `requirements.txt`).

## Project structure
| File | Purpose |
|---|---|
| `main.py` | Entry point: loads saved data (or demo data) and starts the GUI |
| `gui.py` | Tkinter interface: sidebar tree, file list, breadcrumbs, tabs |
| `operations.py` | Controller: create / rename / delete / restore / undo / navigate |
| `file_model.py` | `Node` base class, `File`, name validation |
| `folder_model.py` | `Folder` = general tree node, recursive tree functions |
| `operation_history.py` | Linked list (history), stack (undo), queue (recent) |
| `search_sort.py` | Recursive search, merge sort, extension filter |
| `storage.py` | JSON save / load |
| `tests/test_explorer.py` | 16 unit tests |

## Where each DSA concept is used
| Concept | Where | Why |
|---|---|---|
| General tree | `Folder.children`, `Node.parent` | Folders hold any number of files/subfolders |
| Recursion | `Folder.tree_lines`, `count`, `total_size`, `search_recursive`, `node_from_dict` | Every operation that must visit all nested items |
| Linked list | `OperationHistory` (head + tail pointers) | History of every operation, O(1) append |
| Stack (LIFO) | `UndoStack` | Undo reverses the most recent operation first |
| Queue (FIFO) | `RecentQueue` (capacity 5) | "Recent operations": oldest leaves when full |
| Hash map | `Folder.children` dict | O(1) lookup and duplicate-name check |
| Searching | `search_recursive` | Find a name anywhere below the root |
| Sorting | `merge_sort`, `sort_items` | Folders first, then files by name / size / type |

## Complexity (n = items in one folder, N = items in the whole tree)
| Operation | Time |
|---|---|
| Create file/folder | O(1) (hash-map insert + duplicate check) |
| List a folder | O(n) |
| Sort a folder | O(n log n) (merge sort) |
| Recursive search | O(N) |
| Display full tree / count / total size | O(N) |
| Push to undo stack / append to history | O(1) |
| Go to parent folder | O(1) (parent pointer) |
| Build a path string | O(depth) |

## Design decisions (good viva answers)
- **Virtual file system**: safe to demo and easy to save/load.
- **Delete = soft delete**: items move to the Recycle Bin and can be restored.
- **Undo** supports create, rename, delete, restore and edit. Navigation is not undoable.
- **Permanently deleting** from the bin clears the undo stack, because old undo
  records might point to items that no longer exist.
- If the original folder of a restored item is gone, it is restored to the root;
  name clashes become `name (1).ext`.

## Demo checklist
1. New Folder: College, then open it, create Semester 3, then DSA (breadcrumb shows Home > College > Semester 3 > DSA).
2. New File in different folders (e.g. `notes.txt`, `code.py`). Double-click a text file to edit it.
3. Click breadcrumbs / the sidebar / **Up** to navigate back.
4. **Directory Tree** button shows the recursive tree.
5. Type a name in **Search**: results come from all nested folders; double-click to jump there.
6. Rename, delete, then **Undo** (Ctrl+Z). Check the **History**, **Recent** and **Recycle Bin** tabs.
7. Use **Sort** and **Filter** (.py, .pdf, .txt).
8. Close the app, run it again: everything is still there.

Shortcuts: `Ctrl+Z` undo, `Ctrl+S` save, `Ctrl+F` search, `F2` rename, `Del` delete, `Backspace` up, `F5` refresh.
