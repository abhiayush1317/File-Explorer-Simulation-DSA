"""file_model.py - Node base class and File (a leaf of the general tree)."""
import os
from datetime import datetime

INVALID_CHARS = set('\\/:*?"<>|')


class ExplorerError(Exception):
    """Any user-facing problem: bad name, duplicate, nothing to undo, ..."""


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def validate_name(name):
    """Return the cleaned name or raise ExplorerError."""
    name = (name or "").strip()
    if not name:
        raise ExplorerError("Name cannot be empty.")
    if name in (".", ".."):
        raise ExplorerError('"." and ".." are not valid names.')
    if len(name) > 100:
        raise ExplorerError("Name is too long (max 100 characters).")
    bad = sorted(c for c in name if c in INVALID_CHARS)
    if bad:
        raise ExplorerError("Name cannot contain: " + " ".join(bad))
    return name


def human_size(num):
    if num < 1024:
        return f"{num} B"
    for unit in ("KB", "MB", "GB"):
        num /= 1024
        if num < 1024 or unit == "GB":
            return f"{num:.1f} {unit}"


class Node:
    """Common part of File and Folder. The `parent` pointer lets us walk
    up the tree in O(1) per step (used for 'go back' and for building paths)."""

    is_folder = False
    extension = ""

    def __init__(self, name, created=None, modified=None):
        self.name = name
        self.parent = None
        self.created = created or now_str()
        self.modified = modified or self.created

    def touch(self):
        self.modified = now_str()

    @property
    def path(self):
        """Full path built by following parent pointers up to the root: O(depth)."""
        parts, node = [], self
        while node.parent is not None:
            parts.append(node.name)
            node = node.parent
        return node.name + "/".join(reversed(parts))


class File(Node):
    def __init__(self, name, size=0, content="", created=None, modified=None):
        super().__init__(name, created, modified)
        self.size = size          # bytes
        self.content = content

    @property
    def extension(self):
        return os.path.splitext(self.name)[1].lower()

    @property
    def kind(self):
        return (self.extension[1:].upper() + " File") if self.extension else "File"

    def to_dict(self):
        return {"type": "file", "name": self.name, "size": self.size,
                "content": self.content, "created": self.created,
                "modified": self.modified}

    @classmethod
    def from_dict(cls, d):
        return cls(d["name"], d.get("size", 0), d.get("content", ""),
                   d.get("created"), d.get("modified"))
