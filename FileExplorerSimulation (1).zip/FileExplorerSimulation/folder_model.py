"""folder_model.py - Folder = a node of the GENERAL TREE (any number of children).

children is a dict {name.lower(): node}: a hash map inside the tree, so
add / find / remove by name are O(1) and duplicate names are caught instantly.
"""
from file_model import Node, File, ExplorerError, now_str
from search_sort import sort_items


class Folder(Node):
    is_folder = True
    kind = "File folder"

    def __init__(self, name, created=None, modified=None):
        super().__init__(name, created, modified)
        self.children = {}

    # ---- basic operations (all O(1)) ------------------------------------
    def items(self):
        return list(self.children.values())

    def has(self, name):
        return name.lower() in self.children

    def get(self, name):
        return self.children.get(name.lower())

    def add(self, node):
        key = node.name.lower()
        if key in self.children:
            raise ExplorerError(f'"{node.name}" already exists in {self.path}')
        self.children[key] = node
        node.parent = self
        self.modified = now_str()

    def remove(self, name):
        node = self.children.pop(name.lower())
        node.parent = None
        self.modified = now_str()
        return node

    def rename_child(self, old, new):
        if new.lower() != old.lower() and self.has(new):
            raise ExplorerError(f'"{new}" already exists in {self.path}')
        node = self.children.pop(old.lower())
        node.name = new
        node.touch()
        self.children[new.lower()] = node

    # ---- recursive operations (visit every node once: O(N)) -------------
    def count(self):
        """(number of files, number of folders) in the whole subtree."""
        files = folders = 0
        for child in self.children.values():
            if child.is_folder:
                f, d = child.count()          # recursion
                files += f
                folders += d + 1
            else:
                files += 1
        return files, folders

    def total_size(self):
        return sum(c.total_size() if c.is_folder else c.size
                   for c in self.children.values())

    def tree_lines(self, prefix=""):
        """Yield the lines of the directory tree (recursive generator)."""
        items = sort_items(self.items())
        for i, item in enumerate(items):
            last = i == len(items) - 1
            yield prefix + ("└── " if last else "├── ") + item.name + ("/" if item.is_folder else "")
            if item.is_folder:
                yield from item.tree_lines(prefix + ("    " if last else "│   "))

    def tree_string(self):
        return "\n".join([self.name] + list(self.tree_lines()))

    # ---- persistence ------------------------------------------------------
    def to_dict(self):
        return {"type": "folder", "name": self.name, "created": self.created,
                "modified": self.modified,
                "children": [c.to_dict() for c in self.children.values()]}


def node_from_dict(d):
    """Rebuild a subtree from JSON data (recursive)."""
    if d["type"] == "file":
        return File.from_dict(d)
    if d["type"] == "folder":
        folder = Folder(d["name"], d.get("created"), d.get("modified"))
        for child in d.get("children", []):
            folder.add(node_from_dict(child))
        return folder
    raise ValueError("unknown node type: " + str(d["type"]))
