"""gui.py - Tkinter user interface (sidebar tree, file list, details/history/bin tabs)."""
import tkinter as tk
from tkinter import ttk, messagebox

import storage
from file_model import ExplorerError, human_size
from search_sort import sort_items, filter_by_extension

C = {
    "bg": "#f3f4f8", "panel": "#ffffff", "border": "#e5e7eb", "text": "#1f2937",
    "muted": "#6b7280", "primary": "#4f46e5", "primary_dark": "#3730a3",
    "select": "#e0e7ff", "toolbar": "#1e1b4b", "tool": "#312e81", "tool_hover": "#4338ca",
}
FONT = ("Segoe UI", 10)
SORT_OPTIONS = {
    "Name (A → Z)": ("name", False), "Name (Z → A)": ("name", True),
    "Size (small → large)": ("size", False), "Size (large → small)": ("size", True),
    "Type": ("type", False),
}
EXT_FILTERS = ["All files", ".txt", ".pdf", ".py", ".docx", ".png", ".json", ".md", ".sql"]
DSA_TEXT = """General Tree      -> folder hierarchy (Folder.children, parent pointers)
Recursion         -> directory tree, recursive search, counting
Linked List       -> operation history (OperationHistory)
Stack (LIFO)      -> undo (UndoStack)
Queue (FIFO)      -> recent operations (RecentQueue, last 5)
Hash Map          -> O(1) lookup of children by name
Searching         -> recursive search by name
Sorting           -> merge sort (name / size / type)
JSON              -> persistence between runs"""


class FormDialog(tk.Toplevel):
    """Small modal form: fields = [(label, default), ...]; .result = list or None."""

    def __init__(self, parent, title, fields):
        super().__init__(parent, bg=C["bg"])
        self.title(title)
        self.transient(parent)
        self.resizable(False, False)
        self.result = None
        body = ttk.Frame(self, padding=18)
        body.pack()
        self.entries = []
        for r, (label, default) in enumerate(fields):
            ttk.Label(body, text=label).grid(row=r, column=0, sticky="w", pady=5, padx=(0, 12))
            e = ttk.Entry(body, width=34)
            e.insert(0, default)
            e.grid(row=r, column=1, pady=5)
            self.entries.append(e)
        btns = ttk.Frame(body)
        btns.grid(row=len(fields), column=0, columnspan=2, sticky="e", pady=(14, 0))
        ttk.Button(btns, text="Cancel", command=self.destroy).pack(side="right", padx=(8, 0))
        ttk.Button(btns, text="OK", style="Accent.TButton", command=self._ok).pack(side="right")
        self.bind("<Return>", lambda _e: self._ok())
        self.bind("<Escape>", lambda _e: self.destroy())
        self.entries[0].focus_set()
        self.entries[0].select_range(0, "end")
        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - self.winfo_width()) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - self.winfo_height()) // 3
        self.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        self.wait_visibility()
        self.grab_set()
        self.wait_window()

    def _ok(self):
        self.result = [e.get() for e in self.entries]
        self.destroy()


class ExplorerApp:
    def __init__(self, root, fs):
        self.root, self.fs = root, fs
        self.search_mode = False
        self.tree_items = {}           # sidebar iid -> Folder
        self.row_items = {}            # list iid -> Node
        self.bin_items = {}            # bin iid -> entry
        self.expanded = {fs.root.path}
        root.title("File Explorer Simulation  |  DSA Mini Project")
        root.geometry("1200x740")
        root.minsize(980, 600)
        root.configure(bg=C["bg"])
        self._styles()
        self._icons()
        self._menu()
        self._toolbar()
        self._navbar()
        self._statusbar()
        self._body()
        self._bindings()
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.refresh()

    # ================= building the UI =================
    def _styles(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure(".", font=FONT, background=C["bg"], foreground=C["text"])
        s.configure("Panel.TFrame", background=C["panel"])
        s.configure("TLabel", background=C["bg"])
        s.configure("Head.TLabel", background=C["panel"], foreground=C["muted"],
                    font=("Segoe UI", 9, "bold"))
        s.configure("Treeview", background=C["panel"], fieldbackground=C["panel"],
                    rowheight=28, borderwidth=0, font=FONT)
        s.configure("Treeview.Heading", background="#eef0ff", foreground=C["primary_dark"],
                    font=("Segoe UI", 10, "bold"), relief="flat", padding=6)
        s.map("Treeview", background=[("selected", C["select"])],
              foreground=[("selected", C["primary_dark"])])
        s.map("Treeview.Heading", background=[("active", "#dfe3ff")])
        s.configure("Tool.TButton", background=C["tool"], foreground="white",
                    padding=(12, 7), borderwidth=0, relief="flat", focuscolor=C["tool"])
        s.map("Tool.TButton", background=[("active", C["tool_hover"])])
        s.configure("Accent.TButton", background=C["primary"], foreground="white",
                    padding=(14, 6), borderwidth=0, focuscolor=C["primary"])
        s.map("Accent.TButton", background=[("active", C["primary_dark"])])
        s.configure("TButton", padding=(10, 5))
        s.configure("TNotebook", background=C["bg"], borderwidth=0)
        s.configure("TNotebook.Tab", padding=(16, 7), font=FONT)
        s.map("TNotebook.Tab", background=[("selected", C["panel"])],
              foreground=[("selected", C["primary"])])

    def _icons(self):
        def img(w, h, *rects):
            im = tk.PhotoImage(width=w, height=h)
            for color, box in rects:
                im.put(color, to=box)
            return im
        self.icons = {
            "folder": img(20, 16, ("#f59e0b", (1, 1, 9, 4)), ("#fbbf24", (1, 3, 19, 15)),
                          ("#f59e0b", (1, 3, 19, 5))),
            "file": img(20, 16, ("#94a3b8", (4, 0, 16, 16)), ("#ffffff", (5, 1, 15, 15)),
                        ("#6366f1", (5, 1, 15, 4)), ("#cbd5e1", (6, 6, 14, 7)),
                        ("#cbd5e1", (6, 9, 14, 10)), ("#cbd5e1", (6, 12, 12, 13))),
            "drive": img(20, 16, ("#475569", (1, 3, 19, 14)), ("#64748b", (2, 4, 18, 13)),
                         ("#e2e8f0", (4, 7, 11, 9)), ("#22c55e", (14, 9, 16, 11))),
        }

    def _menu(self):
        bar = tk.Menu(self.root)
        m = tk.Menu(bar, tearoff=0)
        m.add_command(label="Save          Ctrl+S", command=self.save)
        m.add_separator()
        m.add_command(label="Exit", command=self.on_close)
        bar.add_cascade(label="File", menu=m)
        m = tk.Menu(bar, tearoff=0)
        m.add_command(label="Undo          Ctrl+Z", command=self.undo)
        bar.add_cascade(label="Edit", menu=m)
        m = tk.Menu(bar, tearoff=0)
        m.add_command(label="Directory Tree", command=self.show_tree)
        m.add_command(label="Refresh          F5", command=self.refresh)
        bar.add_cascade(label="View", menu=m)
        m = tk.Menu(bar, tearoff=0)
        m.add_command(label="DSA concepts used", command=lambda: messagebox.showinfo(
            "DSA concepts used", DSA_TEXT, parent=self.root))
        bar.add_cascade(label="Help", menu=m)
        self.root.config(menu=bar)

    def _toolbar(self):
        bar = tk.Frame(self.root, bg=C["toolbar"])
        bar.pack(fill="x")
        tk.Label(bar, text="File Explorer", bg=C["toolbar"], fg="white",
                 font=("Segoe UI", 14, "bold")).pack(side="left", padx=(16, 22), pady=10)
        for text, cmd in [("↑  Up", self.go_up), ("+  Folder", self.new_folder),
                          ("+  File", self.new_file), ("Rename", self.rename),
                          ("Delete", self.delete), ("Undo", self.undo)]:
            ttk.Button(bar, text=text, style="Tool.TButton", command=cmd).pack(side="left", padx=2, pady=8)
        ttk.Button(bar, text="Save", style="Tool.TButton", command=self.save).pack(side="right", padx=(2, 14))
        ttk.Button(bar, text="Directory Tree", style="Tool.TButton",
                   command=self.show_tree).pack(side="right", padx=2)

    def _navbar(self):
        nav = ttk.Frame(self.root, padding=(10, 10, 10, 6))
        nav.pack(fill="x")
        self.crumbs = tk.Frame(nav, bg=C["panel"], highlightbackground=C["border"], highlightthickness=1)
        self.crumbs.pack(side="left", fill="x", expand=True, ipady=4)
        self.search_var = tk.StringVar()
        self.filter_var = tk.StringVar(value=EXT_FILTERS[0])
        self.sort_var = tk.StringVar(value="Name (A → Z)")
        ttk.Label(nav, text="Sort").pack(side="right", padx=(0, 0))
        box = ttk.Combobox(nav, textvariable=self.sort_var, values=list(SORT_OPTIONS),
                           state="readonly", width=19)
        box.pack(side="right", padx=(4, 12))
        box.bind("<<ComboboxSelected>>", lambda _e: self.refresh_list())
        box = ttk.Combobox(nav, textvariable=self.filter_var, values=EXT_FILTERS,
                           state="readonly", width=10)
        box.pack(side="right", padx=(4, 12))
        box.bind("<<ComboboxSelected>>", lambda _e: self.refresh_list())
        ttk.Label(nav, text="Filter").pack(side="right")
        ttk.Button(nav, text="Clear", command=lambda: self.search_var.set("")).pack(side="right", padx=(4, 12))
        self.search_entry = ttk.Entry(nav, textvariable=self.search_var, width=22)
        self.search_entry.pack(side="right", padx=(4, 0))
        ttk.Label(nav, text="Search").pack(side="right", padx=(16, 0))
        self.search_var.trace_add("write", self._on_search)

    def _statusbar(self):
        bar = tk.Frame(self.root, bg=C["toolbar"])
        bar.pack(side="bottom", fill="x")
        self.status_var, self.count_var = tk.StringVar(value="Ready"), tk.StringVar()
        tk.Label(bar, textvariable=self.status_var, bg=C["toolbar"], fg="white",
                 font=("Segoe UI", 9), anchor="w").pack(side="left", padx=12, pady=4)
        tk.Label(bar, textvariable=self.count_var, bg=C["toolbar"], fg="#c7d2fe",
                 font=("Segoe UI", 9)).pack(side="right", padx=12)

    def _body(self):
        paned = ttk.PanedWindow(self.root, orient="horizontal")
        paned.pack(fill="both", expand=True, padx=10, pady=(0, 8))
        side = ttk.Frame(paned, style="Panel.TFrame")
        ttk.Label(side, text="FOLDER TREE", style="Head.TLabel").pack(anchor="w", padx=12, pady=(10, 4))
        self.tree = ttk.Treeview(side, show="tree", selectmode="browse")
        self.tree.column("#0", width=240)
        sb = ttk.Scrollbar(side, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)
        paned.add(side, weight=1)

        right = ttk.PanedWindow(paned, orient="vertical")
        paned.add(right, weight=4)
        top = ttk.Frame(right, style="Panel.TFrame")
        self.list = ttk.Treeview(top, columns=("type", "size", "modified", "location"), selectmode="extended")
        self.list.heading("#0", text="Name", anchor="w", command=lambda: self._heading_sort("name"))
        self.list.heading("type", text="Type", anchor="w", command=lambda: self._heading_sort("type"))
        self.list.heading("size", text="Size", anchor="e", command=lambda: self._heading_sort("size"))
        self.list.heading("modified", text="Date modified", anchor="w")
        self.list.heading("location", text="Location", anchor="w")
        self.list.column("#0", width=300)
        self.list.column("type", width=120)
        self.list.column("size", width=90, anchor="e")
        self.list.column("modified", width=160)
        self.list.column("location", width=260)
        sb = ttk.Scrollbar(top, orient="vertical", command=self.list.yview)
        self.list.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.list.pack(fill="both", expand=True)
        right.add(top, weight=3)

        nb = ttk.Notebook(right)
        right.add(nb, weight=2)
        # Details tab
        self.details = ttk.Frame(nb, style="Panel.TFrame", padding=14)
        nb.add(self.details, text="Details")
        # History tab (linked list)
        tab = ttk.Frame(nb, style="Panel.TFrame")
        nb.add(tab, text="History")
        self.hist = ttk.Treeview(tab, columns=("time", "action", "details"), show="headings")
        for col, text, w in (("time", "Time", 150), ("action", "Action", 130), ("details", "Details", 500)):
            self.hist.heading(col, text=text, anchor="w")
            self.hist.column(col, width=w)
        self.hist.pack(fill="both", expand=True)
        # Recent tab (queue)
        tab = ttk.Frame(nb, style="Panel.TFrame", padding=10)
        nb.add(tab, text="Recent (Queue)")
        ttk.Label(tab, text="Last 5 operations, oldest first (FIFO queue)", style="Head.TLabel").pack(anchor="w")
        self.recent_list = tk.Listbox(tab, font=FONT, relief="flat", highlightthickness=0,
                                      activestyle="none", bg=C["panel"])
        self.recent_list.pack(fill="both", expand=True, pady=(6, 0))
        # Recycle bin tab
        tab = ttk.Frame(nb, style="Panel.TFrame")
        nb.add(tab, text="Recycle Bin")
        row = ttk.Frame(tab, style="Panel.TFrame", padding=6)
        row.pack(side="bottom", fill="x")
        ttk.Button(row, text="Restore", style="Accent.TButton", command=self.restore).pack(side="left")
        ttk.Button(row, text="Delete forever", command=self.delete_forever).pack(side="left", padx=6)
        ttk.Button(row, text="Empty bin", command=self.empty_bin).pack(side="left")
        self.bin = ttk.Treeview(tab, columns=("origin", "when"), selectmode="browse")
        self.bin.heading("#0", text="Name", anchor="w")
        self.bin.heading("origin", text="Original location", anchor="w")
        self.bin.heading("when", text="Deleted at", anchor="w")
        self.bin.column("#0", width=220)
        self.bin.column("origin", width=280)
        self.bin.column("when", width=160)
        self.bin.pack(fill="both", expand=True)

        self.menu = tk.Menu(self.root, tearoff=0)
        for label, cmd in (("Open", self.open_selected), ("Rename", self.rename), ("Delete", self.delete)):
            self.menu.add_command(label=label, command=cmd)
        self.menu.add_separator()
        for label, cmd in (("New Folder", self.new_folder), ("New File", self.new_file), ("Undo", self.undo)):
            self.menu.add_command(label=label, command=cmd)

    def _bindings(self):
        self.list.bind("<Double-1>", self._on_double_click)
        self.list.bind("<Return>", lambda _e: self.open_selected())
        self.list.bind("<Delete>", lambda _e: self.delete())
        self.list.bind("<BackSpace>", lambda _e: self.go_up())
        self.list.bind("<F2>", lambda _e: self.rename())
        self.list.bind("<<TreeviewSelect>>", self._on_list_select)
        for ev in ("<Button-3>", "<Button-2>", "<Control-Button-1>"):
            self.list.bind(ev, self._context_menu)
        self.tree.bind("<<TreeviewSelect>>", self._on_tree_select)
        self.tree.bind("<<TreeviewOpen>>", lambda _e: self._track_expand(True))
        self.tree.bind("<<TreeviewClose>>", lambda _e: self._track_expand(False))
        self.root.bind("<Control-z>", lambda _e: self.undo())
        self.root.bind("<Control-s>", lambda _e: self.save())
        self.root.bind("<Control-f>", lambda _e: self.search_entry.focus_set())
        self.root.bind("<F5>", lambda _e: self.refresh())

    # ================= refreshing =================
    def refresh(self):
        self._rebuild_tree()
        self._rebuild_crumbs()
        self.refresh_list()
        self._refresh_side_tabs()
        self._update_status()

    def _rebuild_tree(self):
        self.tree.delete(*self.tree.get_children())
        self.tree_items.clear()
        ancestors, node = set(), self.fs.current
        while node is not None:
            ancestors.add(id(node))
            node = node.parent
        current_iid = None

        def add(parent_iid, folder):          # recursion builds the sidebar tree
            nonlocal current_iid
            is_root = folder is self.fs.root
            iid = self.tree.insert(
                parent_iid, "end", text=" " + ("Home  (C:/)" if is_root else folder.name),
                image=self.icons["drive" if is_root else "folder"],
                open=(folder.path in self.expanded or id(folder) in ancestors))
            self.tree_items[iid] = folder
            if folder is self.fs.current:
                current_iid = iid
            for sub in sort_items([c for c in folder.items() if c.is_folder]):
                add(iid, sub)

        add("", self.fs.root)
        if current_iid:
            self.tree.selection_set(current_iid)
            self.tree.see(current_iid)

    def _rebuild_crumbs(self):
        for w in self.crumbs.winfo_children():
            w.destroy()
        chain, n = [], self.fs.current
        while n is not None:
            chain.append(n)
            n = n.parent
        chain.reverse()
        for i, folder in enumerate(chain):
            here = folder is self.fs.current
            lbl = tk.Label(self.crumbs, text="Home" if folder is self.fs.root else folder.name,
                           bg=C["panel"], fg=C["text"] if here else C["primary"], cursor="hand2",
                           font=("Segoe UI", 10, "bold" if here else "normal"), padx=5)
            lbl.pack(side="left")
            lbl.bind("<Button-1>", lambda _e, f=folder: self.navigate(f))
            if i < len(chain) - 1:
                tk.Label(self.crumbs, text="›", bg=C["panel"], fg=C["muted"]).pack(side="left")

    def refresh_list(self):
        self.list.delete(*self.list.get_children())
        self.row_items.clear()
        query = self.search_var.get().strip()
        self.search_mode = bool(query)
        items = self.fs.search(query) if self.search_mode else self.fs.current.items()
        ext = self.filter_var.get()
        if ext != EXT_FILTERS[0]:
            items = filter_by_extension(items, ext)
        by, rev = SORT_OPTIONS[self.sort_var.get()]
        items = sort_items(items, by, rev)
        self.list.configure(displaycolumns=("type", "size", "modified", "location") if self.search_mode
                            else ("type", "size", "modified"))
        for n in items:
            iid = self.list.insert(
                "", "end", text=" " + n.name, image=self.icons["folder" if n.is_folder else "file"],
                values=(n.kind, "" if n.is_folder else human_size(n.size), n.modified,
                        n.parent.path if n.parent else ""))
            self.row_items[iid] = n
        if not items:
            self.list.insert("", "end", text="   " + ("No results found" if self.search_mode
                                                      else "This folder is empty"))
        self._show_details(self.fs.current)

    def _refresh_side_tabs(self):
        self.hist.delete(*self.hist.get_children())
        for e in reversed(list(self.fs.history)):          # newest first
            self.hist.insert("", "end", values=(e["time"], e["action"], e["details"]))
        self.recent_list.delete(0, "end")
        for text in self.fs.recent:
            self.recent_list.insert("end", "  " + text)
        self.bin.delete(*self.bin.get_children())
        self.bin_items.clear()
        for entry in self.fs.recycle_bin:
            item = entry["item"]
            iid = self.bin.insert("", "end", text=" " + item.name,
                                  image=self.icons["folder" if item.is_folder else "file"],
                                  values=(entry["origin_path"], entry["deleted_at"]))
            self.bin_items[iid] = entry

    def _update_status(self):
        st = self.fs.stats()
        self.count_var.set(f"{st['here']} items here   |   Total: {st['files']} files, {st['folders']} folders "
                           f"({human_size(st['size'])})   |   Undo steps: {st['undo']}")
        if self.search_mode:
            self.set_status(f"{len(self.row_items)} result(s) for \"{self.search_var.get().strip()}\" "
                            "(recursive search)")

    def set_status(self, text):
        self.status_var.set(text)

    def _show_details(self, node):
        for w in self.details.winfo_children():
            w.destroy()
        is_root = node is self.fs.root
        info = [("Name", "Home (C:/)" if is_root else node.name),
                ("Type", "Drive" if is_root else node.kind),
                ("Extension", node.extension or "—")]
        if node.is_folder:
            files, folders = node.count()
            info += [("Size", human_size(node.total_size())), ("Contains", f"{files} files, {folders} folders")]
        else:
            info.append(("Size", human_size(node.size)))
        info += [("Location", node.path), ("Created", node.created), ("Modified", node.modified)]
        for r, (k, v) in enumerate(info):
            ttk.Label(self.details, text=k, style="Head.TLabel").grid(row=r, column=0, sticky="w", pady=2, padx=(0, 24))
            ttk.Label(self.details, text=v, background=C["panel"]).grid(row=r, column=1, sticky="w", pady=2)

    # ================= events =================
    def _selected_nodes(self):
        return [self.row_items[i] for i in self.list.selection() if i in self.row_items]

    def _on_list_select(self, _e=None):
        nodes = self._selected_nodes()
        self._show_details(nodes[0] if len(nodes) == 1 else self.fs.current)

    def _on_tree_select(self, _e=None):
        sel = self.tree.selection()
        folder = self.tree_items.get(sel[0]) if sel else None
        if folder is not None and folder is not self.fs.current:
            self.navigate(folder)

    def _track_expand(self, opened):
        folder = self.tree_items.get(self.tree.focus())
        if folder is not None:
            (self.expanded.add if opened else self.expanded.discard)(folder.path)

    def _on_search(self, *_):
        self.refresh_list()
        self._update_status()
        if not self.search_mode:
            self.set_status("Ready")

    def _heading_sort(self, by):
        options = [k for k, v in SORT_OPTIONS.items() if v[0] == by]
        cur = self.sort_var.get()
        nxt = options[(options.index(cur) + 1) % len(options)] if cur in options else options[0]
        self.sort_var.set(nxt)
        self.refresh_list()

    def _on_double_click(self, event):
        if self.list.identify_row(event.y):
            self.open_selected()

    def _context_menu(self, event):
        iid = self.list.identify_row(event.y)
        if iid and iid not in self.list.selection():
            self.list.selection_set(iid)
        try:
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()

    # ================= actions =================
    def _run(self, func, *args):
        try:
            result = func(*args)
        except ExplorerError as e:
            messagebox.showerror("Action not possible", str(e), parent=self.root)
            return False, None
        self.refresh()
        return True, result

    def _guard(self):
        if self.search_mode:
            self.set_status("Clear the search first - double-click a result to jump to it.")
            return False
        return True

    def navigate(self, folder):
        self.search_var.set("")
        try:
            self.fs.go_to(folder)
        except ExplorerError as e:
            messagebox.showerror("Action not possible", str(e), parent=self.root)
        self.refresh()
        self.set_status(f"Opened {self.fs.current.path}")

    def go_up(self):
        self.search_var.set("")
        if self.fs.go_up():
            self.refresh()
            self.set_status(f"Moved up to {self.fs.current.path}")
        else:
            self.set_status("Already at the root folder")

    def open_selected(self):
        nodes = self._selected_nodes()
        if not nodes:
            return
        node = nodes[0]
        if node.is_folder:
            self.navigate(node)
        elif self.search_mode:
            self.navigate(node.parent)
            for iid, n in self.row_items.items():
                if n is node:
                    self.list.selection_set(iid)
                    self.list.see(iid)
        else:
            self.open_editor(node)

    def new_folder(self):
        if not self._guard():
            return
        dlg = FormDialog(self.root, "New Folder", [("Folder name", "New Folder")])
        if dlg.result is None:
            return
        ok, _ = self._run(self.fs.create_folder, dlg.result[0])
        if ok:
            self.set_status(f'Folder "{dlg.result[0].strip()}" created')

    def new_file(self):
        if not self._guard():
            return
        dlg = FormDialog(self.root, "New File", [("File name (with extension)", "untitled.txt"), ("Size (KB)", "1")])
        if dlg.result is None:
            return
        try:
            size = int(max(0.0, float(dlg.result[1] or 0)) * 1024)
        except ValueError:
            messagebox.showerror("Action not possible", "Size must be a number.", parent=self.root)
            return
        ok, _ = self._run(self.fs.create_file, dlg.result[0], size)
        if ok:
            self.set_status(f'File "{dlg.result[0].strip()}" created')

    def rename(self):
        if not self._guard():
            return
        nodes = self._selected_nodes()
        if len(nodes) != 1:
            self.set_status("Select exactly one item to rename")
            return
        dlg = FormDialog(self.root, "Rename", [("New name", nodes[0].name)])
        if dlg.result is None:
            return
        ok, _ = self._run(self.fs.rename, nodes[0].name, dlg.result[0])
        if ok:
            self.set_status(f'Renamed to "{dlg.result[0].strip()}"')

    def delete(self):
        if not self._guard():
            return
        nodes = self._selected_nodes()
        if not nodes:
            self.set_status("Select something to delete first")
            return
        what = f'"{nodes[0].name}"' if len(nodes) == 1 else f"{len(nodes)} items"
        if not messagebox.askyesno("Move to Recycle Bin", f"Move {what} to the Recycle Bin?", parent=self.root):
            return
        try:
            for n in nodes:
                self.fs.delete(n.name)
        except ExplorerError as e:
            messagebox.showerror("Action not possible", str(e), parent=self.root)
        self.refresh()
        self.set_status(f"Moved {what} to the Recycle Bin")

    def undo(self):
        ok, msg = self._run(self.fs.undo)
        if ok:
            self.set_status(msg)

    def _selected_bin_entry(self):
        sel = self.bin.selection()
        if not sel:
            self.set_status("Select an item in the Recycle Bin first")
            return None
        return self.bin_items[sel[0]]

    def restore(self):
        entry = self._selected_bin_entry()
        if entry:
            ok, item = self._run(self.fs.restore, entry)
            if ok:
                self.set_status(f'Restored "{item.name}" to {item.parent.path}')

    def delete_forever(self):
        entry = self._selected_bin_entry()
        if entry and messagebox.askyesno(
                "Delete forever", f'Permanently delete "{entry["item"].name}"?\n'
                "This cannot be undone and clears the Undo stack.", parent=self.root):
            self._run(self.fs.delete_forever, entry)

    def empty_bin(self):
        if self.fs.recycle_bin and messagebox.askyesno(
                "Empty Recycle Bin", "Permanently delete everything in the Recycle Bin?\n"
                "This clears the Undo stack.", parent=self.root):
            self._run(self.fs.empty_bin)

    def open_editor(self, file):
        win = tk.Toplevel(self.root)
        win.title(f"{file.name}  -  {file.path}")
        win.geometry("660x440")
        bar = ttk.Frame(win, padding=8)
        bar.pack(side="bottom", fill="x")
        text = tk.Text(win, wrap="word", font=("Consolas", 11), padx=12, pady=10, relief="flat", undo=True)
        text.pack(fill="both", expand=True)
        text.insert("1.0", file.content)

        def save_it():
            ok, _ = self._run(self.fs.edit_file, file, text.get("1.0", "end-1c"))
            if ok:
                self.set_status(f'Saved "{file.name}"')
        ttk.Button(bar, text="Save", style="Accent.TButton", command=save_it).pack(side="right")
        ttk.Button(bar, text="Close", command=win.destroy).pack(side="right", padx=8)

    def show_tree(self):
        win = tk.Toplevel(self.root)
        win.title("Complete directory tree (recursive)")
        win.geometry("520x580")
        files, folders = self.fs.root.count()
        ttk.Label(win, text=f"{folders} folders, {files} files", padding=10).pack(anchor="w")
        txt = tk.Text(win, font=("Consolas", 11), padx=12, pady=8, relief="flat")
        txt.insert("1.0", self.fs.root.tree_string())
        txt.configure(state="disabled")
        txt.pack(fill="both", expand=True)

    def save(self):
        try:
            storage.save(self.fs)
            self.set_status(f"Saved to {storage.DATA_FILE.name}")
        except OSError as e:
            messagebox.showerror("Save failed", str(e), parent=self.root)

    def on_close(self):
        try:
            storage.save(self.fs)
        except OSError as e:
            if not messagebox.askyesno("Save failed", f"{e}\n\nExit anyway?", parent=self.root):
                return
        self.root.destroy()
