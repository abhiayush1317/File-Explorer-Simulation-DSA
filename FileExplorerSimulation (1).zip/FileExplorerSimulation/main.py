"""main.py - entry point.  Run:  python main.py"""
import tkinter as tk

import storage
from gui import ExplorerApp
from operations import FileSystem, seed_sample_data


def main():
    fs = storage.load()
    if fs is None:                      # first run (or broken save file)
        fs = FileSystem()
        seed_sample_data(fs)
    root = tk.Tk()
    ExplorerApp(root, fs)
    root.mainloop()


if __name__ == "__main__":
    main()
