"""operation_history.py - Linked List (history), Stack (undo), Queue (recent)."""
from collections import deque

from file_model import now_str


class HistoryNode:
    __slots__ = ("data", "next")

    def __init__(self, data):
        self.data = data
        self.next = None


class OperationHistory:
    """Singly LINKED LIST with head and tail pointers.
    append is O(1) (thanks to the tail pointer); traversal is O(n)."""

    def __init__(self):
        self.head = None
        self.tail = None
        self._size = 0

    def append(self, action, details, time=None):
        node = HistoryNode({"time": time or now_str(), "action": action, "details": details})
        if self.tail is None:
            self.head = self.tail = node
        else:
            self.tail.next = node
            self.tail = node
        self._size += 1

    def __iter__(self):
        cur = self.head
        while cur is not None:
            yield cur.data
            cur = cur.next

    def __len__(self):
        return self._size

    def to_list(self):
        return list(self)


class UndoStack:
    """STACK (LIFO): the last operation done is the first one undone. All O(1)."""

    def __init__(self):
        self._items = []

    def push(self, action):
        self._items.append(action)

    def pop(self):
        return self._items.pop()

    def peek(self):
        return self._items[-1]

    def is_empty(self):
        return not self._items

    def clear(self):
        self._items.clear()

    def __len__(self):
        return len(self._items)


class RecentQueue:
    """QUEUE (FIFO) with a fixed capacity: when full, the oldest entry leaves."""

    def __init__(self, capacity=5):
        self._items = deque()
        self.capacity = capacity

    def enqueue(self, text):
        if len(self._items) == self.capacity:
            self._items.popleft()          # dequeue the oldest
        self._items.append(text)

    def __iter__(self):
        return iter(self._items)

    def __len__(self):
        return len(self._items)
