"""operations.py - the controller: every file/folder operation lives here.

The GUI never touches the tree directly; it calls these methods, which
validate input, change the tree, push an undo record and log the history.
"""
import os

from file_model import ExplorerError, File, validate_name, now_str
from folder_model import Folder
from operation_history import OperationHistory, UndoStack, RecentQueue
from search_sort import search_recursive


class FileSystem:
    def __init__(self):
        self.root = Folder("C:/")
        self.current = self.root
        self.history = OperationHistory()   # linked list
        self.undo_stack = UndoStack()       # stack
        self.recent = RecentQueue(5)        # queue
        self.recycle_bin = []               # list of dict entries

    # ---- helpers ------------------------------------------------------------
    def _log(self, action, details):
        self.history.append(action, details)
        self.recent.enqueue(f"{action}: {details}")

    def is_attached(self, folder):
        """True if `folder` is still connected to the root (walk up parents)."""
        node = folder
        while node.parent is not None:
            node = node.parent
        return node is self.root

    def resolve_path(self, path):
        """'C:/College/DSA' -> Folder, or None if it does not exist."""
        node = self.root
        for part in [p for p in path.replace("\\", "/").split("/") if p and p != "C:"]:
            child = node.get(part)
            if child is None or not child.is_folder:
                return None
            node = child
        return node

    @staticmethod
    def _unique_name(folder, node):
        if node.is_folder:
            base, ext = node.name, ""
        else:
            base, ext = os.path.splitext(node.name)
        n = 1
        while folder.has(f"{base} ({n}){ext}"):
            n += 1
        return f"{base} ({n}){ext}"

    @staticmethod
    def _check_file_name(name):
        stem, ext = os.path.splitext(name)
        if not stem or len(ext) < 2:
            raise ExplorerError("A file needs an extension, e.g. notes.txt")

    def _find(self, name):
        node = self.current.get(name)
        if node is None:
            raise ExplorerError(f'"{name}" was not found in {self.current.path}')
        return node

    # ---- create / rename / delete / edit ---------------------------------------
    def create_folder(self, name):
        folder = Folder(validate_name(name))
        self.current.add(folder)
        self.undo_stack.push({"op": "create", "item": folder, "parent": self.current})
        self._log("CREATE FOLDER", folder.path)
        return folder

    def create_file(self, name, size_bytes=0):
        name = validate_name(name)
        self._check_file_name(name)
        file = File(name, size=max(0, int(size_bytes)))
        self.current.add(file)
        self.undo_stack.push({"op": "create", "item": file, "parent": self.current})
        self._log("CREATE FILE", file.path)
        return file

    def rename(self, old_name, new_name):
        node = self._find(old_name)
        new_name = validate_name(new_name)
        if not node.is_folder:
            self._check_file_name(new_name)
        if new_name == node.name:
            return node
        old_path = node.path
        old = node.name
        self.current.rename_child(old, new_name)
        self.undo_stack.push({"op": "rename", "parent": self.current, "old": old, "new": new_name})
        self._log("RENAME", f"{old_path} -> {new_name}")
        return node

    def delete(self, name):
        """Soft delete: the item moves to the Recycle Bin."""
        node = self._find(name)
        path = node.path
        self.current.remove(node.name)
        entry = {"item": node, "origin": self.current,
                 "origin_path": self.current.path, "deleted_at": now_str()}
        self.recycle_bin.append(entry)
        self.undo_stack.push({"op": "delete", "item": node, "parent": self.current, "entry": entry})
        self._log("DELETE", path)
        return node

    def edit_file(self, file, content):
        if file.is_folder or file.parent is None or not self.is_attached(file.parent):
            raise ExplorerError("That file no longer exists.")
        if content == file.content:
            return
        self.undo_stack.push({"op": "edit", "item": file, "content": file.content,
                              "size": file.size, "modified": file.modified})
        file.content = content
        file.size = len(content.encode("utf-8"))
        file.touch()
        self._log("EDIT FILE", file.path)

    # ---- navigation ------------------------------------------------------------
    def open_folder(self, name):
        node = self._find(name)
        if not node.is_folder:
            raise ExplorerError(f'"{name}" is a file, not a folder.')
        self.current = node
        return node

    def go_up(self):
        """Back to the parent folder via the parent pointer: O(1)."""
        if self.current.parent is None:
            return False
        self.current = self.current.parent
        return True

    def go_to(self, folder):
        if not self.is_attached(folder):
            raise ExplorerError("That folder no longer exists.")
        self.current = folder

    # ---- recycle bin -----------------------------------------------------------
    def restore(self, entry):
        if entry not in self.recycle_bin:
            raise ExplorerError("That item is no longer in the Recycle Bin.")
        item, target = entry["item"], entry["origin"]
        if not self.is_attached(target):
            target = self.root                      # original folder is gone
        if target.has(item.name):
            item.name = self._unique_name(target, item)
        target.add(item)
        self.recycle_bin.remove(entry)
        self.undo_stack.push({"op": "restore", "item": item, "entry": entry})
        self._log("RESTORE", item.path)
        return item

    def delete_forever(self, entry):
        self.recycle_bin.remove(entry)
        self.undo_stack.clear()     # old undo records may point at this item
        self._log("DELETE FOREVER", entry["item"].name)

    def empty_bin(self):
        count = len(self.recycle_bin)
        self.recycle_bin.clear()
        self.undo_stack.clear()
        self._log("EMPTY BIN", f"{count} item(s) removed")

    # ---- undo (STACK, LIFO) ------------------------------------------------------
    def undo(self):
        if self.undo_stack.is_empty():
            raise ExplorerError("Nothing to undo.")
        act = self.undo_stack.pop()
        op, fallback = act["op"], self.root
        if op == "create":
            item = act["item"]
            act["parent"].remove(item.name)
            fallback = act["parent"]
            msg = f"Undid creation of {item.name}"
        elif op == "delete":
            act["parent"].add(act["item"])
            self.recycle_bin.remove(act["entry"])
            msg = f"Undid deletion of {act['item'].name}"
        elif op == "rename":
            act["parent"].rename_child(act["new"], act["old"])
            msg = f"Undid rename {act['old']} -> {act['new']}"
        elif op == "edit":
            item = act["item"]
            item.content, item.size, item.modified = act["content"], act["size"], act["modified"]
            msg = f"Undid edit of {item.name}"
        else:  # restore
            item = act["item"]
            item.parent.remove(item.name)
            self.recycle_bin.append(act["entry"])
            msg = f"Undid restore of {item.name}"
        if not self.is_attached(self.current):      # we may be standing in a removed folder
            self.current = fallback if self.is_attached(fallback) else self.root
        self._log("UNDO", msg)
        return msg

    # ---- search / stats -----------------------------------------------------------
    def search(self, query):
        return search_recursive(self.root, query)

    def stats(self):
        files, folders = self.root.count()
        return {"files": files, "folders": folders,
                "size": self.root.total_size(),
                "here": len(self.current.children),
                "undo": len(self.undo_stack),
                "bin": len(self.recycle_bin)}


def seed_sample_data(fs):
    """Demo content used the first time the app runs."""
    def folder(parent, name):
        f = Folder(name)
        parent.add(f)
        return f

    def file(parent, name, kb=0, content=""):
        size = len(content.encode()) if content else int(kb * 1024)
        parent.add(File(name, size=size, content=content))

    college = folder(fs.root, "College")
    sem3 = folder(college, "Semester 3")
    dsa = folder(sem3, "DSA")
    dbms = folder(sem3, "DBMS")
    folder(sem3, "Labs")
    file(dsa, "notes.txt", content="DSA notes\n- Trees\n- Stacks and Queues\n- Linked Lists\n")
    file(dsa, "linked_list.py", 3.1)
    file(dsa, "stack_queue.py", 2.8)
    file(dsa, "tree_assignment.pdf", 350)
    file(dbms, "er_diagram.png", 420)
    file(dbms, "schema.sql", 1.6)
    docs = folder(fs.root, "Documents")
    file(docs, "resume.pdf", 180)
    file(docs, "todo.txt", 0.5)
    pics = folder(fs.root, "Pictures")
    file(pics, "trip.png", 2048)
    projects = folder(fs.root, "Projects")
    file(projects, "main.py", 4.4)
    file(projects, "README.md", 1.2)
    fs.current = fs.root
