"""search_sort.py - recursive search, merge sort and extension filter."""


def search_recursive(folder, query, results=None):
    """RECURSION: visit every node below `folder`; collect names containing
    `query` (case-insensitive). Time O(N) for N nodes in the subtree."""
    if results is None:
        results = []
    q = query.lower()
    for child in folder.children.values():
        if q in child.name.lower():
            results.append(child)
        if child.is_folder:
            search_recursive(child, query, results)
    return results


def merge_sort(items, key=lambda x: x, reverse=False):
    """Stable merge sort, O(n log n). Written by hand to show the algorithm."""
    if len(items) <= 1:
        return list(items)
    mid = len(items) // 2
    left = merge_sort(items[:mid], key, reverse)
    right = merge_sort(items[mid:], key, reverse)
    merged, i, j = [], 0, 0
    while i < len(left) and j < len(right):
        a, b = key(left[i]), key(right[j])
        take_left = a >= b if reverse else a <= b
        if take_left:
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1
    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged


def sort_items(items, by="name", reverse=False):
    """Folders first, then files. `by` is 'name', 'size' or 'type'."""
    folders = [n for n in items if n.is_folder]
    files = [n for n in items if not n.is_folder]
    folders = merge_sort(folders, key=lambda n: n.name.lower(), reverse=reverse)
    keys = {
        "name": lambda n: n.name.lower(),
        "size": lambda n: (n.size, n.name.lower()),
        "type": lambda n: (n.extension, n.name.lower()),
    }
    return folders + merge_sort(files, keys[by], reverse)


def filter_by_extension(items, ext):
    """Keep only files whose extension matches, e.g. '.py' or 'py'. O(n)."""
    ext = ext.lower() if ext.startswith(".") else "." + ext.lower()
    return [n for n in items if not n.is_folder and n.extension == ext]
