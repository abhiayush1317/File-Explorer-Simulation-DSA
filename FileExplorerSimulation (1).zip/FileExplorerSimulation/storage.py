"""storage.py - save / load the whole virtual file system as JSON."""
import json
import os
from pathlib import Path

from file_model import ExplorerError
from folder_model import Folder, node_from_dict
from operations import FileSystem

DATA_FILE = Path(__file__).resolve().parent / "data" / "explorer.json"


def save(fs, path=DATA_FILE):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "version": 1,
        "root": fs.root.to_dict(),
        "current": fs.current.path,
        "recycle_bin": [{"item": e["item"].to_dict(), "origin": e["origin_path"],
                         "deleted_at": e["deleted_at"]} for e in fs.recycle_bin],
        "history": fs.history.to_list(),
    }
    tmp = path.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, path)          # never leaves a half-written file behind


def load(path=DATA_FILE):
    """Return a FileSystem, or None if there is no (valid) save file."""
    path = Path(path)
    if not path.exists():
        return None
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        fs = FileSystem()
        root = node_from_dict(data["root"])
        if not isinstance(root, Folder):
            raise ValueError("root must be a folder")
        fs.root = root
        fs.current = fs.resolve_path(data.get("current", "")) or root
        for e in data.get("recycle_bin", []):
            origin = fs.resolve_path(e.get("origin", "")) or root
            fs.recycle_bin.append({"item": node_from_dict(e["item"]), "origin": origin,
                                   "origin_path": e.get("origin", "C:/"),
                                   "deleted_at": e.get("deleted_at", "")})
        for h in data.get("history", []):
            fs.history.append(h["action"], h["details"], h["time"])
        return fs
    except (OSError, ValueError, KeyError, TypeError, ExplorerError):
        try:                       # keep the broken file for inspection
            path.replace(path.with_suffix(".corrupt.json"))
        except OSError:
            pass
        return None
