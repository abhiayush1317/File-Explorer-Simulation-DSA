"""Run from the project folder:  python -m unittest discover -s tests -v"""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import storage
from file_model import ExplorerError
from operations import FileSystem, seed_sample_data
from operation_history import OperationHistory, RecentQueue, UndoStack
from search_sort import filter_by_extension, merge_sort, search_recursive, sort_items


def nested_fs():
    fs = FileSystem()
    fs.create_folder("College")
    fs.open_folder("College")
    fs.create_folder("Semester 3")
    fs.open_folder("Semester 3")
    fs.create_folder("DSA")
    fs.open_folder("DSA")
    fs.create_file("notes.txt", 2048)
    fs.create_file("code.py", 100)
    fs.create_file("Report.pdf", 5000)
    return fs


class TreeTests(unittest.TestCase):
    def test_nested_paths_and_navigation(self):
        fs = nested_fs()
        self.assertEqual(fs.current.path, "C:/College/Semester 3/DSA")
        self.assertTrue(fs.go_up())
        self.assertEqual(fs.current.name, "Semester 3")
        fs.go_up(); fs.go_up()
        self.assertFalse(fs.go_up())            # root has no parent

    def test_duplicate_and_invalid_names(self):
        fs = FileSystem()
        fs.create_folder("A")
        for bad in ("a", "", "  ", "x/y", "bad*name"):
            with self.assertRaises(ExplorerError):
                fs.create_folder(bad)
        with self.assertRaises(ExplorerError):
            fs.create_file("noextension")

    def test_counts_and_tree_string(self):
        fs = nested_fs()
        self.assertEqual(fs.root.count(), (3, 3))
        text = fs.root.tree_string()
        self.assertIn("└── College/", text)
        self.assertIn("notes.txt", text)
        self.assertEqual(fs.stats()["size"], 2048 + 100 + 5000)


class SearchSortTests(unittest.TestCase):
    def test_recursive_search_finds_nested(self):
        fs = nested_fs()
        self.assertEqual([n.name for n in search_recursive(fs.root, "NOTES")], ["notes.txt"])
        self.assertEqual(len(search_recursive(fs.root, "s")), 3)   # Semester 3, DSA, notes.txt
        self.assertEqual(search_recursive(fs.root, "zzz"), [])

    def test_sort_and_filter(self):
        fs = nested_fs()
        items = fs.current.items()
        self.assertEqual([n.name for n in sort_items(items)], ["code.py", "notes.txt", "Report.pdf"])
        self.assertEqual([n.name for n in sort_items(items, "size", True)], ["Report.pdf", "notes.txt", "code.py"])
        self.assertEqual([n.name for n in filter_by_extension(items, "PY")], ["code.py"])
        self.assertEqual(merge_sort([5, 2, 9, 1, 5, 6]), [1, 2, 5, 5, 6, 9])
        self.assertEqual(merge_sort([3, 1, 2], reverse=True), [3, 2, 1])


class OperationTests(unittest.TestCase):
    def test_rename_and_undo(self):
        fs = nested_fs()
        fs.rename("notes.txt", "ideas.txt")
        self.assertIsNotNone(fs.current.get("ideas.txt"))
        fs.undo()
        self.assertIsNotNone(fs.current.get("notes.txt"))
        self.assertIsNone(fs.current.get("ideas.txt"))

    def test_delete_restore_and_undo(self):
        fs = nested_fs()
        fs.delete("code.py")
        self.assertIsNone(fs.current.get("code.py"))
        self.assertEqual(len(fs.recycle_bin), 1)
        fs.undo()                                   # undo the delete
        self.assertIsNotNone(fs.current.get("code.py"))
        self.assertEqual(len(fs.recycle_bin), 0)
        fs.delete("code.py")
        item = fs.restore(fs.recycle_bin[0])
        self.assertIs(fs.current.get("code.py"), item)
        fs.undo()                                   # undo the restore -> back in bin
        self.assertEqual(len(fs.recycle_bin), 1)

    def test_restore_when_origin_gone_goes_to_root(self):
        fs = nested_fs()
        fs.delete("code.py")
        fs.go_up(); fs.go_up()
        fs.delete("Semester 3")                     # origin folder now in the bin
        fs.restore(fs.recycle_bin[0])               # code.py
        self.assertIsNotNone(fs.root.get("code.py"))

    def test_undo_create_moves_out_of_removed_folder(self):
        fs = FileSystem()
        fs.create_folder("X")
        fs.open_folder("X")
        fs.undo()                                   # removes X while we stand inside it
        self.assertIs(fs.current, fs.root)

    def test_undo_edit_and_empty_stack(self):
        fs = nested_fs()
        f = fs.current.get("notes.txt")
        fs.edit_file(f, "hello")
        self.assertEqual(f.size, 5)
        fs.undo()
        self.assertEqual((f.content, f.size), ("", 2048))
        fs2 = FileSystem()
        with self.assertRaises(ExplorerError):
            fs2.undo()

    def test_empty_bin_clears_undo(self):
        fs = nested_fs()
        fs.delete("code.py")
        fs.empty_bin()
        self.assertEqual(len(fs.recycle_bin), 0)
        self.assertTrue(fs.undo_stack.is_empty())


class HistoryTests(unittest.TestCase):
    def test_linked_list_order_and_size(self):
        h = OperationHistory()
        for i in range(3):
            h.append("A", str(i))
        self.assertEqual([e["details"] for e in h], ["0", "1", "2"])
        self.assertEqual(len(h), 3)

    def test_stack_lifo_and_queue_fifo(self):
        s = UndoStack()
        s.push(1); s.push(2)
        self.assertEqual((s.peek(), s.pop(), s.pop()), (2, 2, 1))
        q = RecentQueue(3)
        for i in range(5):
            q.enqueue(i)
        self.assertEqual(list(q), [2, 3, 4])

    def test_every_operation_is_logged(self):
        fs = nested_fs()
        self.assertEqual(len(fs.history), 6)
        self.assertEqual(len(fs.recent), 5)


class StorageTests(unittest.TestCase):
    def test_save_and_load_roundtrip(self):
        fs = FileSystem()
        seed_sample_data(fs)
        fs.open_folder("College")
        fs.create_folder("Extra")
        fs.delete("Extra")
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "explorer.json")
            storage.save(fs, path)
            loaded = storage.load(path)
        self.assertEqual(loaded.root.tree_string(), fs.root.tree_string())
        self.assertEqual(loaded.current.path, "C:/College")
        self.assertEqual(len(loaded.recycle_bin), 1)
        self.assertEqual(len(loaded.history), len(fs.history))

    def test_corrupt_file_returns_none(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "explorer.json")
            with open(path, "w") as f:
                f.write("{ not json")
            self.assertIsNone(storage.load(path))


if __name__ == "__main__":
    unittest.main()
